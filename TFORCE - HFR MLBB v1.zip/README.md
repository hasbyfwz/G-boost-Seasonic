# This module is free of use
### Line modified in module:
- ro.product.model=MI 9T Pro