# TFORCE-SEASONIC
All In One 

## Supported 
- Snapdragon
- MediaTek
- Exynos
- HiSilicon Kirin
- Others

## Supported Architectures
- Arm & Arm64
- x86 & x86_64

## Requirements
- I recommend using MAGISK version 20.3

## Changelog 

- v1.0 - FULL REPACK

# GamesTURBO
# Memory
# FPSUNLOCKED
# FPSCHAPS
# System Tweaks
# Disable Logcat
# Apps Tweaks
# SystemTweaks
# Responsiveness & Speed Tweak
# Dalvik Virtual Machine Tweaks
# TouchX
# Scrolling speed tweaks
# Display tweaks
# Supports Google Camera
# MediaTweaks
# Video streaming optimization tweaks

- v2.0

# Turn off vertical sync
# Improve global touch screen response
# Sound
# Add ToucX Remove Touch11



## Support


## Links
- <a href="https://t.me/GBoost-seasonic">Official Telegram Channel</a>
- <a href="https://t.me/hasbyfwz">Telegram Account</a>
- <a href="https://forum.xda-developers.com/apps/magisk/official-magisk-v7-universal-systemless-t3473445">Latest Stable Magisk</a>
