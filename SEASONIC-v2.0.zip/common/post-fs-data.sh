##########################################################################################
# TFORCE-SEASONIC
# VERSION = v2.0
# DATE = 08-10-2020
##########################################################################################
#!/system/bin/sh

if [ -x "$(command -v setenforce)" ]
then
	setenforce 0
else
	echo -n 0 > /sys/fs/selinux/enforce;
fi

# This script will be executed in post-fs-data mode
# More info in the main Magisk thread
