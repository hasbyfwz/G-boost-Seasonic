##########################################################################################
# TFORCE-SEASONIC
# VERSION = v2.0
# DATE = 08-10-2020
##########################################################################################
#!/system/bin/sh

# Wait for boot to be completed
while [ ! "$(getprop ro.board.platform)" == "1" ! "$(getprop sys.io.scheduler)" == "noop" ! "$(getprop sys.post_boot.parsed)" == "1" ! "$(getprop persist.vendor.spectrum.profile)" == "0" ! "$(getprop sys.boot_completed)" == "1" ! "$(getprop vendor.post_boot.parsed)" == "1" ]; do
 sleep 1
done
 sleep 1
if [ -x "$(command -v setenforce)" ]
then
	setenforce 0
else
	echo -n 0 > /sys/fs/selinux/enforce;
fi;
 sleep 1
# Google Service Reduce Drain Tweaks Set Config
sleep '0.001'
su -c 'pm enable com.google.android.googlequicksearchbox'
sleep '0.001'
su -c 'pm enable com.google.android.apps.turbo'
sleep '0.001'
su -c 'pm enable com.google.android.apps.wellbeing'
sleep '0.001'
su -c 'pm enable com.google.android.gm'
sleep '0.001'
su -c 'pm enable com.google.android.play.games'

# Dt2W Fixed Tweaks Set Config
sleep 1
cat /sys/touchpanel/double_tap;
echo '0' > /sys/touchpanel/double_tap;
sleep 1
cat /sys/touchpanel/double_tap;
echo '1' > /sys/touchpanel/double_tap;

# GPU Booster Tweaks Set Config
cat /dev/cpuset/foreground/cpus;
echo '0-3,4-7' > /dev/cpuset/foreground/cpus;
restorecon -R /dev/cpuset/foreground/cpus;
cat /dev/cpuset/foreground/effective_cpus;
echo '0-3,4-7' > /dev/cpuset/foreground/effective_cpus;
restorecon -R /dev/cpuset/foreground/effective_cpus;
echo '0-7' > /dev/cpuset/top-app/cpus;
echo '0-7' > /dev/cpuset/top-app/effective_cpus;
echo '1' > /dev/stune/foreground/schedtune.prefer_idle;
echo '1' > /dev/stune/top-app/schedtune.prefer_idle;
echo '5' > /dev/stune/top-app/schedtune.boost;
echo '0' > /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/thermal_pwrlevel;
echo '0' > /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/throttling;

# This script will be executed in late_start service mode
# More info in the main Magisk thread
