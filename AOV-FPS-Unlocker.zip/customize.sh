# Set to true if you need to load system.prop
PROPFILE=true
