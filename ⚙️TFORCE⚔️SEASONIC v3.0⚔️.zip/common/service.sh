##########################################################################################
# TFORCE-SEASONIC
# VERSION = v3.0
# DATE = 08-10-2020
##########################################################################################
#!/system/bin/sh

# Wait for boot to be completed
while [ ! "$(getprop ro.board.platform)" == "1" ! "$(getprop sys.io.scheduler)" == "noop" ! "$(getprop sys.post_boot.parsed)" == "1" ! "$(getprop persist.vendor.spectrum.profile)" == "0" ! "$(getprop sys.boot_completed)" == "1" ! "$(getprop vendor.post_boot.parsed)" == "1" ]; do
 sleep 1
done
 sleep 1
if [ -x "$(command -v setenforce)" ]
then
	setenforce 0
else
	echo -n 0 > /sys/fs/selinux/enforce;
fi;
 sleep 1

# Google Service Reduce Drain Tweaks Set Config
sleep '0.001'
su -c 'pm enable com.google.android.googlequicksearchbox'
sleep '0.001'
su -c 'pm enable com.google.android.apps.turbo'
sleep '0.001'
su -c 'pm enable com.google.android.apps.wellbeing'
sleep '0.001'
su -c 'pm enable com.google.android.gm'
sleep '0.001'
su -c 'pm enable com.google.android.play.games'

# Dt2W Fixed Tweaks Set Config
sleep 1
cat /sys/touchpanel/double_tap;
echo '0' > /sys/touchpanel/double_tap;
sleep 1
cat /sys/touchpanel/double_tap;
echo '1' > /sys/touchpanel/double_tap;

# G-Booster Tweaks Set Config
cat /dev/cpuset/foreground/cpus;
echo '0-3,4-7' > /dev/cpuset/foreground/cpus;
restorecon -R /dev/cpuset/foreground/cpus;
cat /dev/cpuset/foreground/effective_cpus;
echo '0-3,4-7' > /dev/cpuset/foreground/effective_cpus;
restorecon -R /dev/cpuset/foreground/effective_cpus;
echo '0-7' > /dev/cpuset/top-app/cpus;
echo '0-7' > /dev/cpuset/top-app/effective_cpus;
echo '1' > /dev/stune/foreground/schedtune.prefer_idle;
echo '1' > /dev/stune/top-app/schedtune.prefer_idle;
echo '5' > /dev/stune/top-app/schedtune.boost;
echo '0' > /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/thermal_pwrlevel;
echo '0' > /sys/devices/soc/5000000.qcom,kgsl-3d0/kgsl/kgsl-3d0/throttling;

if [ -e /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors ]; then
 cpu_governors=/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors
fi
if [ -e /sys/devices/system/cpu/cpu4/cpufreq/scaling_available_frequencies ]; then
 cpu_freq=/sys/devices/system/cpu/cpu4/cpufreq/scaling_available_frequencies
fi
if [ -e /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_frequencies ]; then
 cpu_freq0=/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_frequencies
fi
if [ -e /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq ]; then
 cpu_max=/sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq
fi
if [ -e /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_min_freq ]; then
 cpu_min=/sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_min_freq
fi
if [ -e /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq ]; then
 setmin0=`cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq`
fi
if [ -e /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_min_freq ]; then
 setmin4=`cat /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_min_freq`
fi
if [ -e /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq ]; then
 setmax0=`cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq`
fi
if [ -e /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq ]; then
 setmax4=`cat /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq`
fi
if [ -e /sys/block/mmcblk0/queue/scheduler ]; then
 io_scheduler=/sys/block/mmcblk0/queue/scheduler
fi
ext4blocks="/sys/fs/ext4/mmcblk0p*"

# Gaming Mode Script
while true; do
 sleep 20
 if [ $(top -n 1 -d 1 | head -n 12 | grep -o -e 'mobile' -e 'skynet' -e 'cputhrottlingtest' -e 'codm' -e 'legends' -e 'nexon' -e 'ea.game' -e 'konami' -e 'bandainamco' -e 'netmarble' -e 'GoogleCam' -e 'edengames' -e 'camera' -e 'snapcam' -e 'tencent' -e 'moonton' -e 'gameloft' -e 'netease' -e 'garena' | head -n 1) ]; then
            echo "performance" > /sys/class/devfreq/cc00000.qcom,vidc:venus_bus_ddr/governor
            echo "performance" > /sys/class/devfreq/mmc0/governor
            echo "performance" > /sys/class/devfreq/mmc1/governor
            echo "performance" > /sys/class/devfreq/soc:devfreq_spdm_cpu/governor
            echo "performance" > /sys/class/devfreq/soc:qcom,cpubw/governor
            echo "performance" > /sys/class/devfreq/soc:qcom,gpubw/governor
            echo "performance" > /sys/class/devfreq/soc:qcom,kgsl-busmon/governor
            echo "performance" > /sys/class/devfreq/soc:qcom,memlat-cpu0/governor
            echo "performance" > /sys/class/devfreq/soc:qcom,memlat-cpu4/governor
            echo "performance" > /sys/class/devfreq/soc:qcom,mincpubw/governor

echo "1" > /sys/class/kgsl/kgsl-3d0/force_clk_on
echo "1" > /sys/class/kgsl/kgsl-3d0/force_bus_on
echo "1" > /sys/class/kgsl/kgsl-3d0/force_rail_on
echo "1" > /sys/class/kgsl/kgsl-3d0/force_no_nap

write /dev/stune/background/schedtune.boost "40"
write /dev/stune/background/schedtune.prefer_idle "0"
write /dev/stune/background/schedtune.colocate "0"
write /dev/stune/background/schedtune.sched_boost_enabled "0"

write /dev/stune/foreground/schedtune.boost "40"
write /dev/stune/foreground/schedtune.prefer_idle "0"
write /dev/stune/foreground/schedtune.colocate "0"
write /dev/stune/foreground/schedtune.sched_boost_enabled "0"

write /dev/stune/rt/schedtune.boost "40"
write /dev/stune/rt/schedtune.prefer_idle "0"
write /dev/stune/rt/schedtune.colocate "0"
write /dev/stune/rt/schedtune.sched_boost_enabled "0"

write /dev/stune/top-app/schedtune.boost "40"
write /dev/stune/top-app/schedtune.prefer_idle "0"
write /dev/stune/top-app/schedtune.colocate "0"
write /dev/stune/top-app/schedtune.sched_boost_enabled "0"

write /dev/stune/schedtune.boost "40"
write /dev/stune/schedtune.prefer_idle "0"
write /dev/stune/schedtune.colocate "0"
write /dev/stune/schedtune.sched_boost_enabled "0"

 else
 fi;
done

write /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor performance
write /sys/devices/system/cpu/cpufreq/performance/go_hispeed_load 80
write /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay 0
write /sys/devices/system/cpu/cpufreq/performance/boost 1
write /sys/module/msm_performance/parameters/touchboost 1
write /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpufreq/performance/align_windows 1
write /sys/devices/soc/1c00000.qcom,kgsl-3d0/devfreq/1c00000.qcom,kgsl-3d0/governor performance
write /sys/class/kgsl/kgsl-3d0/devfreq/governor msm-adreno-tz
write /sys/module/adreno_idler/parameters/adreno_idler_active 0
write /sys/module/lazyplug/parameters/nr_possible_cores 8
write /dev/cpuset/foreground/cpus 0-3,4-7
write /dev/cpuset/foreground/boost/cpus 4-7
write /dev/cpuset/top-app/cpus 0-7

# Wait for boot to finish completely
while [[ `getprop sys.boot_completed` -ne 1 ]]
do
       sleep 1
done

# Sleep an additional 60s to ensure init is finished
sleep 60

# Setup tweaks
Fusionproject

# This script will be executed in late_start service mode
# More info in the main Magisk thread
